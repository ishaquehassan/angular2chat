# scss-mixins
Here is some commonly used mixins i've created using scss and scss math library 
